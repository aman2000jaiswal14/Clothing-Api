from django.contrib import admin
from .models import MyntraClothes
# Register your models here.



@admin.register(MyntraClothes)
class MyntraClothesAdmin(admin.ModelAdmin):

    list_display = ('Title', 'Category', 'SubCategory1', 'SubCategory2')
    search_fields = ('Title',)
