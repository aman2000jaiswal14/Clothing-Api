from elasticsearch_dsl import analyzer, token_filter, tokenizer
from django_elasticsearch_dsl import Document, fields, Index
from .models import MyntraClothes

PUBLISHER_INDEX = Index('myntra_clothes')
PUBLISHER_INDEX.settings(
    number_of_shards = 1,
    number_of_replicas = 0
)


custom_analyzer = analyzer('custom_analyzer',
    tokenizer='standard',
    filter=['lowercase', token_filter(
            'shingle_filter', type='shingle',
            min_shingle_size=2, max_shingle_size=3
        )]
)

@PUBLISHER_INDEX.doc_type
class MyntraDocument(Document):
    Title = fields.TextField(analyzer=custom_analyzer)
    SubCategory3 = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Brand = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Category = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    SubCategory1 = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    SubCategory2 = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Occasion = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Colour = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Fit = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Fabric = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Stretch = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Wash_Care = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Neck = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Length = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Pattern = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Pattern_Coverage = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Print = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Type = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Bottom_Type = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Bottom_Pattern = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Bottom_Fabric = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Bottom_Closure = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Lining = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Shape = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Collar = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Sleeve_Length = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Sleeve_Styling = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Slit_Detail = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Transparency = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Waistband = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Weave_Pattern = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Stitch = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Straps = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Padding = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Distress = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Fade = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Closure = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Top_Type = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Top_Shape = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Top_Fabric = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Top_Length = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Top_Pattern = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Dupatta = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Dupatta_Border = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Dupatta_Fabric = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Dupatta_Pattern = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Hash = fields.TextField(fields={'raw': fields.KeywordField()})
    Selling_price = fields.FloatField()
    Original_price = fields.FloatField()
    Ratings = fields.FloatField()
    Images = fields.TextField(fields={'raw': fields.KeywordField()})
    Item_url = fields.TextField(fields={'raw': fields.KeywordField()})

    class Django:
        # The django model associated with this Document
        model = MyntraClothes

        class Django:
            # The django model associated with this Document
            model = MyntraClothes

            # # The fields of the model you want to be indexed in Elasticsearch
            # fields = [
            #     'Info',
            #     'Available_Colours',
            #     # 'Title',
            #     'Description',
            #     'Images',
            #     'Item_url',
            #     'Features',
            #     'Main_Trend',
            #     'Surface_Styling',
            #     'Technology',
            #     'Number_of_Pockets',
            #     'Sport',
            #     'Seam',
            #     'Ornamentation',
            #     'Hood',
            #     'Hemline',
            #     'Colour_Family',
            #     'CountryOfOrigin',
            #     'Design_Styling',
            #     'Coverage',
            #     'get_all_images'
            #     # 'Ratings'
            # ]


'''











from django_elasticsearch_dsl import (
        Document,fields,Index
)

from elasticsearch_dsl import analyzer, token_filter, tokenizer
from .models import AjioDB

PUBLISHER_INDEX = Index('ajiodb')
PUBLISHER_INDEX.settings(
    number_of_shards = 1,
    number_of_replicas = 0
)

custom_analyzer = analyzer('custom_analyzer',
    tokenizer='standard',
    filter=['lowercase', token_filter(
            'shingle_filter', type='shingle',
            min_shingle_size=2, max_shingle_size=3
        )]
)

@PUBLISHER_INDEX.doc_type
class AjioDBElastic(Document):
    product_id = fields.IntegerField()
    source = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Category = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Subcategory1 = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Subcategory2 = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Title = fields.TextField(analyzer=custom_analyzer)
    Brand = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Description = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    product_detail = fields.ObjectField()
    Design_Styling = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    SeasonYear = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Occasion = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    ManufacturedBy = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    CountryOfOrigin = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    currentPrice = fields.IntegerField()
    orginalPrice = fields.IntegerField()
    discount = fields.IntegerField()
    currencyIso = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Item_url = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Fabric = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Wash_Care = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Fit = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Model_Chest_Size = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Model_Height = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Pattern = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Model_Waist_Size = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    PrimaryColor = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    SecondaryColor = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Sleeve_Styling = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Print = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Neck = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Collar = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Sport = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    Closure = fields.TextField(fields={'raw': fields.KeywordField()},analyzer="keyword")
    images = fields.ObjectField()

    class Django(object):
        model = AjioDB

'''