from django.db import models


# This model will only work with myntra data
class MyntraClothes(models.Model):
    Available_Colours = models.TextField(null=True)
    Bottom_Closure = models.TextField(null=True)
    Bottom_Fabric = models.TextField(null=True)
    Bottom_Pattern = models.TextField(null=True)
    Bottom_Type = models.TextField(null=True)
    Brand = models.TextField()
    Category = models.TextField()
    Closure = models.TextField(null=True)
    Collar = models.TextField(null=True)
    Colour = models.TextField(null=True)
    Colour_Family = models.TextField(null=True)
    CountryOfOrigin = models.TextField(null=True)
    Coverage = models.TextField(null=True)
    Description = models.TextField()
    Design_Styling = models.TextField(null=True)
    Distress = models.TextField(null=True)
    Dupatta = models.TextField(null=True)
    Dupatta_Border = models.TextField(null=True)
    Dupatta_Fabric = models.TextField(null=True)
    Dupatta_Pattern = models.TextField(null=True)
    Fabric = models.TextField(null=True)
    Fade = models.TextField(null=True)
    Features = models.TextField(null=True)
    Fit = models.TextField(null=True)
    Hemline = models.TextField(null=True)
    Hood = models.TextField(null=True)
    Images = models.TextField(null=True)
    Item_url = models.TextField(null=True)
    Length = models.TextField(null=True)
    Lining = models.TextField(null=True)
    Main_Trend = models.TextField(null=True)
    Neck = models.TextField(null=True)
    Number_of_Pockets = models.TextField(null=True)
    Occasion = models.TextField(null=True)
    Original_price = models.TextField(null=True)
    Ornamentation = models.TextField(null=True)
    Padding = models.TextField(null=True)
    Pattern = models.TextField(null=True)
    Pattern_Coverage = models.TextField(null=True)
    Print = models.TextField(null=True)
    Ratings = models.TextField(null=True)
    Seam = models.TextField(null=True)
    Selling_price = models.TextField(null=True)
    Shape = models.TextField(null=True)
    Sleeve_Length = models.TextField(null=True)
    Sleeve_Styling = models.TextField(null=True)
    Slit_Detail = models.TextField(null=True)
    Sport = models.TextField(null=True)
    Stitch = models.TextField(null=True)
    Straps = models.TextField(null=True)
    Stretch = models.TextField(null=True)
    SubCategory1 = models.TextField(null=True)
    SubCategory2 = models.TextField(null=True)
    SubCategory3 = models.TextField(null=True)
    Surface_Styling = models.TextField(null=True)
    Technology = models.TextField(null=True)
    Title = models.TextField(null=True)
    Top_Fabric = models.TextField(null=True)
    Top_Length = models.TextField(null=True)
    Top_Pattern = models.TextField(null=True)
    Top_Shape = models.TextField(null=True)
    Top_Type = models.TextField(null=True)
    Transparency = models.TextField(null=True)
    Type = models.TextField(null=True)
    Waistband = models.TextField(null=True)
    Wash_Care = models.TextField(null=True)
    Weave_Pattern = models.TextField(null=True)
    Hash = models.TextField(null=True)
    Info = models.TextField(null=True)
    class Meta:
        verbose_name_plural = 'MyntraClothes'
        # ordering = ["Selling_price","Ratings"]


    def __str__(self):
        return self.Title


    def get_all_images(self):
        img = self.Images
        img = img.strip('[]').split(',')
        print(img)
        return img














'''
from django.db import models
from django.contrib.postgres.fields import ArrayField
from jsonfield import JSONField
# Create your models here.

class AnyAbstractModel(models.Model):
    name = models.TextField()

class Todo(models.Model):
    task = models.CharField(max_length=30)
    description = models.CharField(max_length=100)
    category =  models.CharField(max_length=30)

class AjioDB(models.Model):
    product_id = models.IntegerField(primary_key=True)
    source = models.CharField(max_length=20)
    Category = models.CharField(max_length=20)
    Subcategory1 = models.CharField(max_length=30)
    Subcategory2 = models.CharField(max_length=30)
    Title = models.CharField(max_length=30)
    Brand = models.CharField(max_length=30)
    Description = models.TextField()
    product_detail = JSONField()
    Design_Styling = models.CharField(max_length=30)
    SeasonYear = models.CharField(max_length=10)
    Occasion = models.CharField(max_length=30)
    ManufacturedBy = models.CharField(max_length=50)
    CountryOfOrigin = models.CharField(max_length=30)
    currentPrice = models.IntegerField()
    orginalPrice = models.IntegerField()
    discount = models.IntegerField()
    currencyIso = models.CharField(max_length=10)
    Item_url = models.URLField()
    Fabric = models.CharField(max_length=30)
    Wash_Care = models.CharField(max_length=30)
    Fit = models.CharField(max_length=30)
    Model_Chest_Size = models.CharField(max_length=30)
    Model_Height = models.CharField(max_length=30)
    Pattern = models.CharField(max_length=30)
    Model_Waist_Size = models.CharField(max_length=30)
    PrimaryColor = models.CharField(max_length=20)
    SecondaryColor = models.CharField(max_length=20)
    Sleeve_Styling = models.CharField(max_length=30)
    Print = models.CharField(max_length=30)
    Neck = models.CharField(max_length=30)
    Collar = models.CharField(max_length=30)
    Sport = models.CharField(max_length=30)
    Closure = models.CharField(max_length=30)
    images = JSONField()

    # class Meta(object):
    #     """Meta options."""

        # ordering = ["id"]

    def __str__(self):
        return self.name

'''