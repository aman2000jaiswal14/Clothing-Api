from django_elasticsearch_dsl_drf.serializers import DocumentSerializer
from .models import MyntraClothes
from .documents import MyntraDocument


class MyntraSerializer(DocumentSerializer):
    class Meta:
        model = MyntraClothes
        document = MyntraDocument
        fields = (
            'Title',
            'SubCategory3',
            'Brand',
            'Category',
            'SubCategory1',
            'SubCategory2',
            'Occasion',
            'Colour',
            'Fit',
            'Fabric',
            'Stretch',
            'Wash_Care',
            'Neck',
            'Length',
            'Pattern',
            'Pattern_Coverage',
            'Print',
            'Type',
            'Bottom_Type',
            'Bottom_Pattern',
            'Bottom_Fabric',
            'Bottom_Closure',
            'Lining',
            'Shape',
            'Collar',
            'Sleeve_Length',
            'Sleeve_Styling',
            'Slit_Detail',
            'Transparency',
            'Waistband',
            'Weave_Pattern',
            'Stitch',
            'Straps',
            'Padding',
            'Distress',
            'Fade',
            'Closure',
            'Top_Type',
            'Top_Shape',
            'Top_Fabric',
            'Top_Length',
            'Top_Pattern',
            'Dupatta',
            'Dupatta_Border',
            'Dupatta_Fabric',
            'Dupatta_Pattern',
            'Hash',
            'Selling_price',
            'Original_price',
            'Ratings',
            'Images',
            'Item_url',
            'get_all_images'

        )

'''
from rest_framework import serializers
from django_elasticsearch_dsl_drf.serializers import DocumentSerializer
from .models import AjioDB
from .documents import AjioDBElastic


class TodoSerializer(serializers.Serializer):
    task = serializers.CharField(max_length=30)
    description = serializers.CharField(max_length=100)
    category = serializers.CharField(max_length=30)

class AjioDBSerializer(serializers.Serializer):
    product_id = serializers.IntegerField()
    source = serializers.CharField(max_length=20)
    Category = serializers.CharField(max_length=20)
    Subcategory1 = serializers.CharField(max_length=30)
    Subcategory2 = serializers.CharField(max_length=30)
    Title = serializers.CharField(max_length=30)
    Brand = serializers.CharField(max_length=30)
    Description = serializers.CharField(style={'base_template': 'textarea.html'})
    product_detail = serializers.JSONField()
    Design_Styling = serializers.CharField(max_length=30)
    SeasonYear = serializers.CharField(max_length=10)
    Occasion = serializers.CharField(max_length=30)
    ManufacturedBy = serializers.CharField(max_length=50)
    CountryOfOrigin = serializers.CharField(max_length=30)
    currentPrice = serializers.IntegerField()
    orginalPrice = serializers.IntegerField()
    discount = serializers.IntegerField()
    currencyIso = serializers.CharField(max_length=10)
    Item_url = serializers.URLField()
    Fabric = serializers.CharField(max_length=30)
    Wash_Care = serializers.CharField(max_length=30)
    Fit = serializers.CharField(max_length=30)
    Model_Chest_Size = serializers.CharField(max_length=30)
    Model_Height = serializers.CharField(max_length=30)
    Pattern = serializers.CharField(max_length=30)
    Model_Waist_Size = serializers.CharField(max_length=30)
    PrimaryColor = serializers.CharField(max_length=20)
    SecondaryColor = serializers.CharField(max_length=20)
    Sleeve_Styling = serializers.CharField(max_length=30)
    Print = serializers.CharField(max_length=30)
    Neck = serializers.CharField(max_length=30)
    Collar = serializers.CharField(max_length=30)
    Sport=  serializers.CharField(max_length=30)
    Closure = serializers.CharField(max_length=30)
    images = serializers.JSONField()


class NewsDocumentSerializer(DocumentSerializer):
    class Meta:
        model = AjioDB
        document = AjioDBElastic
        fields = (
        'id',
        'product_id',
        'source',
        'Category',
        'Subcategory1',
        'Subcategory2',
        'Title',
        'Brand',
        'Description',
        'product_detail',
        'Design_Styling',
        'SeasonYear',
        'Occasion',
        'ManufacturedBy',
        'CountryOfOrigin',
        'currentPrice',
        'orginalPrice',
        'discount',
        'currencyIso',
        'Item_url',
        'Fabric',
        'Wash_Care',
        'Fit',
        'Model_Chest_Size',
        'Model_Height',
        'Pattern',
        'Model_Waist_Size',
        'PrimaryColor',
        'SecondaryColor',
        'Sleeve_Styling',
        'Print',
        'Neck',
        'Collar',
        'Sport',
        'Closure',
        'images'
        )
        # def get_location(self,obj):
        #     try:
        #         return obj.location.to_dict()
        #     except:
        #         return {}

'''