# from elasticsearch import Elasticsearch
# from elasticsearch_dsl import Search
# # # import pandas as pd
# import numpy as np
# es = Elasticsearch()
# # #
# # #
# # # '''
# try:
#     es.indices.delete(index='ajiodb')
# except:
#     pass
# import pymongo
# client = pymongo.MongoClient()
# alldoc = client['demodatabase']['base_api_ajiodb']
# if(not es.indices.exists(index='ajiodb',request_timeout=30)):
#     es.indices.create(index='ajiodb',request_timeout=30)
# else:
#     print("present")
# cols = ['product_id', 'source', 'Category', 'Subcategory1', 'Subcategory2', 'Title', 'Brand', 'Description', 'product_detail', 'Design_Styling', 'Occasion', 'ManufacturedBy', 'CountryOfOrigin', 'currentPrice', 'orginalPrice', 'discount', 'currencyIso', 'Item_url', 'Fabric', 'Wash_Care', 'Fit', 'Pattern', 'PrimaryColor', 'SecondaryColor', 'Sleeve_Styling', 'Print', 'Neck', 'Collar', 'Sport', 'Closure', 'images', 'Model_Height', 'Model_Waist_Size', 'Model_Chest_Size']
# for num,i in enumerate(alldoc.find()):
#
#     # i.pop('_id')
#     # i['product_id'] = num
#     newdoc = {}
#     # for c in cols:
#     #     newdoc[c] = str(i[c])
#     # print(es.index(index='ajiodb', id=num + 1, body=newdoc))
# #     # for c in cols[:10]:
# #     #     newdoc[c] = i[c]
# #     # for c in cols[28:29]:
# #         # newdoc[c] = i[c]
# #
# #     # print(newdoc.keys())
# #     # newdoc['Title'] = i['Title']
# #     # newdoc['source'] = i['source']
# #     # newdoc['Brand'] = i['Brand']
# #     # newdoc['product_id'] = i['product_id']
# #
# #     # print(newdoc)
# #     # print(newdoc.keys())
# #     # print(es.index(index='ajiodb',id=num+1,body = newdoc))
# #     # if(num==0):
# #     #     break
# #     #
#     for c in cols:
#         try:
#             es.indices.delete(index='ajiodb')
#         except:
#             pass
#         if(np.isnan(i[c])):
#             i[c] = ''
#         newdoc[c] = i[c]
#         try:
#             es.index(index='ajiodb', id=num + 1, body=newdoc)
#             print('success  : ',c, "      ", type(i[c]))
#         except:
#             # print()
#             print('failed : ',c,"      ",type(i[c]))
#     if(num==0):
#         break
# # # '''
# # #
# # #
# # # res = es.search(index = 'ajiodb',body={'from':0,'size':100,'query':{'match':{'Title':'Top'}}})
# # # # print(res)
# # # for i in res['hits']['hits']:
# # #     print(i)
# # # # res = client.get(index='myntra_json',id=1)
# # # # print(res)
# # # # print(res['_source'])
# # # # print(client.indices.exists(index='ajiodb'))
# # # # df = pd.DataFrame([hit.to_dict() for hit in s.scan()])
# # # # print(df)
# # # # df.shape()
# # # #
# # # # es = Elasticsearch()
# # # # print(es.indices.exists(index='ajiodb'))
# # # # if(not es.indices.exists(index='ajiodb',request_timeout=30)):
# # # #     es.indices.create(index='ajiodb',request_timeout=30)
# # # # else:
# # # #     print("present")
# # # # print(es.indices.exists(index='ajiodb'))
# # # # # print(es.indices.get_mapping('ajiodb'))
# # # # print(es.cluster.health(wait_for_status='yellow', request_timeout=1))
# # # #
# # #
# # #
# # #
# # #
# # #
# # #
# # #
# # #
# # #
# # #
# # #
# # #
# # # # res = es.search(index = 'ajiodb',body={'from':0,'size':1,'query':{'match':{'Title':'Top'}}})
# # # # print(res)
# # # # for i in res:
# # # #     print(i)
# # # # import pymongo
# # # # client = pymongo.MongoClient()
# # # # alldoc = client['demodatabase']['base_api_ajiodb']
# # # #
# # # #
# # # # for num,i in enumerate(alldoc.find()):
# # # # #
# # # #     i.pop('_id')
# # # #     i['product_id'] = num
# # # #     print(i)
# # # #     es.index(index='ajiodb',body = i)
# # # # #     # print(i)
# # # #     if(num==2):
# # # #         break
# # # #
# # # # #
# # # # # from datetime import datetime
# # # # # from elasticsearch import Elasticsearch
# # # # # es = Elasticsearch()
# # # # # doc = {
# # # # #     'author': 'kimchy',
# # # # #     'text': 'Elasticsearch: cool. bonsai cool.',
# # # # #     'timestamp': datetime.now(),
# # # # # }
# # #
# # # # # res = es.index(index="test-index", id=1, body=doc)
# # # # # print(res['result'])
# # # # # res = es.get(index="test-index", id=1)
# # # # # print(res['_source'])
# # # # # es.indices.refresh(index="test-index")
# # # # #
# # # # # res = es.search(index="test-index", query={"match_all": {}})
# # # # # print("Got %d Hits:" % res['hits']['total']['value'])
# # # # # for hit in res['hits']['hits']:
# # # # #     print("%(timestamp)s %(author)s: %(text)s" % hit["_source"])
