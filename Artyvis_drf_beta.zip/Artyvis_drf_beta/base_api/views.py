from .serializers import MyntraSerializer
from .documents import MyntraDocument
from elasticsearch_dsl import FacetedSearch, TermsFacet, DateHistogramFacet
from django_elasticsearch_dsl_drf.filter_backends import (
    FilteringFilterBackend,
    CompoundSearchFilterBackend,
    OrderingFilterBackend,
    FacetedSearchFilterBackend,
    DefaultOrderingFilterBackend,
    MultiMatchSearchFilterBackend,
    SearchFilterBackend
)
from rest_framework import generics
from django_elasticsearch_dsl_drf.viewsets import DocumentViewSet

class MyntraDocumentView(DocumentViewSet):
    document = MyntraDocument
    serializer_class = MyntraSerializer
    lookup_field = 'Title'
    fielddata = True
    filter_backends = [
        FilteringFilterBackend,
        CompoundSearchFilterBackend,
        MultiMatchSearchFilterBackend,
        FacetedSearchFilterBackend,
        OrderingFilterBackend,
        DefaultOrderingFilterBackend,
        # SearchFilterBackend
    ]

    search_fields = {
        'Title':{'boost':3,'fuzziness': 'AUTO'},
        'SubCategory3':{'boost':4},
        'Brand':{'boost':3},
        'Category':{'boost':4},
        'SubCategory1':{'boost':4},
        'SubCategory2':{'boost':4},
        'Occasion':{'boost':1},
        'Colour':{'boost':2},
        # 'Fit',
        # 'Fabric',
        # 'Stretch',
        # 'Wash_Care',
        # 'Neck',
        # 'Length',
        # 'Pattern',
        # 'Pattern_Coverage',
        # 'Print',
        # 'Type',
        # 'Bottom_Type',
        # 'Bottom_Pattern',
        # 'Bottom_Fabric',
        # 'Bottom_Closure',
        # 'Lining',
        # 'Shape',
        # 'Collar',
        # 'Sleeve_Length',
        # 'Sleeve_Styling',
        # 'Slit_Detail',
        # 'Transparency',
        # 'Waistband',
        # 'Weave_Pattern',
        # 'Stitch',
        # 'Straps',
        # 'Padding',
        # 'Distress',
        # 'Fade',
        # 'Closure',
        # 'Top_Type',
        # 'Top_Shape',
        # 'Top_Fabric',
        # 'Top_Length',
        # 'Top_Pattern',
        # 'Dupatta',
        # 'Dupatta_Border',
        # 'Dupatta_Fabric',
        # 'Dupatta_Pattern',

    }
    faceted_search_fields  = {
        # use bucket aggregations to define facets
        'SubCategory3': {'field': 'SubCategory3.raw','enabled': True},
        'Brand': {'field': 'Brand.raw','enabled': True},
        'Category': {'field': 'Category.raw','enabled': True},
        'SubCategory1': {'field': 'SubCategory1.raw','enabled': True},
        'SubCategory2': {'field': 'SubCategory2.raw','enabled': True},
        'Occasion': {'field': 'Occasion.raw','enabled': True},
        'Colour': {'field': 'Colour.raw','enabled': True},
        'Fit': {'field': 'Fit.raw','enabled': True},
        'Fabric': {'field': 'Fabric.raw','enabled': True},
        'Stretch': {'field': 'Stretch.raw','enabled': True},
        'Wash_Care': {'field': 'Wash_Care.raw','enabled': True},
        'Neck': {'field': 'Neck.raw','enabled': True},
        'Length': {'field': 'Length.raw','enabled': True},
        'Pattern': {'field': 'Pattern.raw','enabled': True},
        'Print': {'field': 'Print.raw','enabled': True},
        'Type': {'field': 'Type.raw','enabled': True},
        'Collar': {'field': 'Collar.raw','enabled': True},
        'Weave_Pattern': {'field': 'Weave_Pattern.raw','enabled': True},
        'Ratings': {'field': 'Ratings.raw','enabled': True}

    }

    filter_fields = {
        # 'Title':'Title',
        'SubCategory3':'SubCategory3',
        'Brand':'Brand',
        'Category':'Category',
        'SubCategory1':'SubCategory1',
        'SubCategory2':'SubCategory2',
        'Occasion':'Occasion',
        'Colour':'Colour',
        'Fit':'Fit',
        'Fabric':'Fabric',
        'Stretch':'Stretch',
        'Wash_Care':'Wash_Care',
        'Neck':'Neck',
        'Length':'Length',
        'Pattern':'Pattern',
        # 'Pattern_Coverage':'Pattern_Coverage',
        'Print':'Print',
        'Type':'Type',
        # 'Bottom_Type':'Bottom_Type',
        # 'Bottom_Pattern':'Bottom_Pattern',
        # 'Bottom_Fabric':'Bottom_Fabric',
        # 'Bottom_Closure':'Bottom_Closure',
        # 'Lining':'Lining',
        # 'Shape':'Shape',
        'Collar':'Collar',
        # 'Sleeve_Length':'Sleeve_Length',
        # 'Sleeve_Styling':'Sleeve_Styling',
        # 'Slit_Detail':'Slit_Detail',
        # 'Transparency':'Transparency',
        # 'Waistband':'Waistband',
        # 'Weave_Pattern':'Weave_Pattern',
        # 'Stitch':'Stitch',
        # 'Straps':'Straps',
        # 'Padding':'Padding',
        # 'Distress':'Distress',
        # 'Fade':'Fade',
        # 'Closure':'Closure',
        # 'Top_Type':'Top_Type',
        # 'Top_Shape':'Top_Shape',
        # 'Top_Fabric':'Top_Fabric',
        # 'Top_Length':'Top_Length',
        # 'Top_Pattern':'Top_Pattern',
        # 'Dupatta':'Dupatta',
        # 'Dupatta_Border':'Dupatta_Border',
        # 'Dupatta_Fabric':'Dupatta_Fabric',
        # 'Dupatta_Pattern':'Dupatta_Pattern',
        # 'Hash':'Hash',
        # 'Selling_price':'Selling_price',
        # 'Original_price':'Original_price',
        'Ratings':'Ratings'
    }

    multi_match_search_fields = {
        'Title':{'boost':4},
        'SubCategory3':{'boost':4},
        'Brand':{'boost':3},
        'Category':{'boost':4},
        'SubCategory1':{'boost':4},
        'SubCategory2':{'boost':4},
        'Occasion':{'boost':1},
        'Colour':{'boost':2},
        # 'Fit',
        # 'Fabric',
        # 'Stretch',
        # 'Wash_Care',
        # 'Neck',
        # 'Length',
        # 'Pattern',
        # 'Pattern_Coverage',
        # 'Print',
        # 'Type',
        # 'Bottom_Type',
        # 'Bottom_Pattern',
        # 'Bottom_Fabric',
        # 'Bottom_Closure',
        # 'Lining',
        # 'Shape',
        # 'Collar',
        # 'Sleeve_Length',
        # 'Sleeve_Styling',
        # 'Slit_Detail',
        # 'Transparency',
        # 'Waistband',
        # 'Weave_Pattern',
        # 'Stitch',
        # 'Straps',
        # 'Padding',
        # 'Distress',
        # 'Fade',
        # 'Closure',
        # 'Top_Type',
        # 'Top_Shape',
        # 'Top_Fabric',
        # 'Top_Length',
        # 'Top_Pattern',
        # 'Dupatta',
        # 'Dupatta_Border',
        # 'Dupatta_Fabric',
        # 'Dupatta_Pattern',
        # 'Hash',
        # 'Selling_price',
        # 'Original_price',
        # 'Ratings'

    }

    multi_match_options = {
        'type': 'phrase',
        "default_operator": "and",
    }
    #
    # fields_fields = {
    #     'Title': 'Title',
    #     # 'source':'source',
    #     'Brand': 'Brand',
    #     'SubCategory1': 'SubCategory1',
    #     'SubCategory2': 'SubCategory2',
    #     'Category': 'Category',
    # }
    ordering_fields = {
        'Selling_price': 'Selling_price',
        'Ratings': 'Ratings'
    }
    ordering = ('Selling_price', 'Ratings')

'''

















from django.shortcuts import render
from .models import Todo
from .serializers import TodoSerializer,AjioDBSerializer,NewsDocumentSerializer
from rest_framework.renderers import JSONRenderer
from django.http import HttpResponse
from .models import AjioDB
from .custom_utils import filter_data
# from django_elasticsearch_dsl_drf.views import BaseDocumentViewSet
from django_elasticsearch_dsl_drf.viewsets import DocumentViewSet
from .documents import AjioDBElastic
from django_elasticsearch_dsl_drf.filter_backends import (
    FilteringFilterBackend,
    CompoundSearchFilterBackend
)
from django_elasticsearch_dsl_drf.viewsets import DocumentViewSet
from django_elasticsearch_dsl_drf.filter_backends import (
    FilteringFilterBackend,
    OrderingFilterBackend,
)


# Create your views here.





def show_AjioDB(request):

    prod = None
    pid = None
    brand = None
    try:
        pid = request.GET.get('pid')
        brand = request.GET.get('brand')
        prod = AjioDB.objects.all()
        if (pid != None):
            prod = prod.filter(product_id=pid)
        if(brand != None):
            prod = prod.filter(Brand=brand)
    except Exception as e:
        print(e)
    serializer = AjioDBSerializer(prod, many=True)
    data_to_show = {}
    for num,data in enumerate(serializer.data):

        data_to_show[num] = filter_data(data)


    json_data = JSONRenderer().render(data_to_show)
    return HttpResponse(json_data, content_type='application/json')





class PublisherDocumentView(DocumentViewSet):
    document = AjioDBElastic
    serializer_class = NewsDocumentSerializer
    lookup_field = 'Title'
    fielddata = True
    filter_backends = [
        FilteringFilterBackend,
        CompoundSearchFilterBackend,
    ]

    search_fields = ('Title','source','Brand','Description','product_detail','Subcategory2','Subcategory1','Category')
    filter_fields = {
        'Title':'Title',
        'source':'source',
        'Brand':'Brand',
        'Occasion':'Occasion',
        'ManufacturedBy':'ManufacturedBy',
        'CountryOfOrigin':'CountryOfOrigin'
    }
    # ordering_fields = ('Title','product_id','source','Brand')
    # ordering = ('Title','product_id','source','Brand')


    multi_match_search_fields = ('Title','source','Brand')
    fields_fields = {
        'Title':'Title',
        'source':'source',
        'Brand':'Brand',
        'Occasion':'Occasion',
        'ManufacturedBy': 'ManufacturedBy',
        'CountryOfOrigin':'CountryOfOrigin'
    }



















def temp(request):
    return HttpResponse("Hello")


def show_Todo(request):
    todo = None
    category_filter = None
    try:
        category_filter = request.GET.get('category')
        if(category_filter==None):
            todo = Todo.objects.all()
        else:
            todo = Todo.objects.filter(category=category_filter)
    except Exception as e:
        todo = Todo.objects.all()
        print(e)


    serializer = TodoSerializer(todo,many=True)
    json_data = JSONRenderer().render(serializer.data)
    return HttpResponse(json_data,content_type='application/json')


'''